package TO;

public class MessageTO {
	
	private int mi_num;
	private String mi_sendid;
	private String mi_receiveid;
	private String mi_content;
	
	public int getMi_num() {
		return mi_num;
	}
	public void setMi_num(int mi_num) {
		this.mi_num = mi_num;
	}
	public String getMi_sendid() {
		return mi_sendid;
	}
	public void setMi_sendid(String mi_sendid) {
		this.mi_sendid = mi_sendid;
	}
	public String getMi_receiveid() {
		return mi_receiveid;
	}
	public void setMi_receiveid(String mi_receiveid) {
		this.mi_receiveid = mi_receiveid;
	}
	public String getMi_content() {
		return mi_content;
	}
	public void setMi_content(String mi_content) {
		this.mi_content = mi_content;
	}

}
